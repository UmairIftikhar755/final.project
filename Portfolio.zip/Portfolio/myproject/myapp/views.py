
from django.shortcuts import render
from .models import Education, Skill, Experience, Project

def index(request):
    educations = Education.objects.all()
    skills = Skill.objects.all()
    experiences = Experience.objects.all()
    projects = Project.objects.all()
    return render(request, 'index.html', {
        'educations': educations,
        'skills': skills,
        'experiences': experiences,
        'projects': projects
    })

